## Warning
You have to provide your own Email address and Password.

## Project Steps
- Sign Up using Google
- Select the writer's name from the writer menu
- Select Satyajit Ray
- Filtering by Best Seller and Shop by Categories
- Adding multiple books to the Cart
- Click on Cart Icon 
- Remove a particular book
- Undo the remove book
- Going to the Shipping page
- Provide Shipping Information